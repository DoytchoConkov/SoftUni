package classroom;

import java.util.ArrayList;
import java.util.List;

public class Classroom {
    public int capacity;
    public List<Student> data;
    public List<Student> students;

    public Classroom(int capacity) {
        this.capacity = capacity;
        this.students = new ArrayList<>();
        this.data = new ArrayList<>();
    }

    public int getCapacity() {
        return this.capacity;
    }

    public List<Student> getStudents() {
        return this.students;
    }

    public int getStudentCount() {
        return this.data.size();
    }

    public List<Student> getData() {
        return data;
    }

    public void setData(List<Student> data) {
        this.data = data;
    }

    public String registerStudent(Student student) {
        boolean isThere = false;
        for (Student currentStudent : this.data) {
            if (currentStudent.getFirstName().equals(student.getFirstName()) && currentStudent.getLastName().equals(student.getLastName())) {
                isThere = true;
                break;
            }
        }
        if (isThere) {
            return "Student is already in the classroom";
        }
        if (this.data.size() >= this.capacity) {
            return "No seats in the classroom";
        }
        this.data.add(student);
        isThere = false;
        for (Student currentStudent : this.students) {
            if (currentStudent.getFirstName().equals(student.getFirstName()) && currentStudent.getLastName().equals(student.getLastName())) {
                isThere = true;
                break;
            }
        }
        if (!isThere) {
            this.students.add(student);
        }

        return String.format("Added student %s %s", student.getFirstName(), student.getLastName());
    }

    public String dismissStudent(Student student) {
        boolean isThere = false;
        Student toRemove = null;
        for (Student currentStudent : this.data) {
            if (currentStudent.getFirstName().equals(student.getFirstName()) && currentStudent.getLastName().equals(student.getLastName())) {
                isThere = true;
                toRemove = currentStudent;
                break;
            }
        }
        if (!isThere) {
            return "Student not found";
        }
        this.data.remove(toRemove);
        return String.format("Removed student %s %s", student.getFirstName(), student.getLastName());
    }

    public String getSubjectInfo(String subject) {
        List<Student> goodStudens = new ArrayList<>();
        for (Student currentStudent : this.students) {
            if (currentStudent.getBestSubject().equals(subject)) {
                goodStudens.add(currentStudent);
            }
        }
        String result = "";
        if (goodStudens.size() > 0) {
            result = String.format("Subject: %s \nStudents: ", subject);
            for (Student stud : goodStudens) {
                result += String.format("\n%s %s ", stud.getFirstName(), stud.getLastName());
            }
        }
        List<Student> goodStudens2 = new ArrayList<>();
        for (Student currentStudent : this.students) {
            if (currentStudent.getBestSubject().equals(subject)) {
                goodStudens2.add(currentStudent);
            }
        }
        if (goodStudens2.size() == 0) {
            result += "No students enrolled for the subject";
        }
        return result;
    }

    public Student getStudent(String firstName, String lastName) {
        Student stud = null;
        for (Student currentStudent : this.data) {
            if (currentStudent.getFirstName().equals(firstName) && currentStudent.getLastName().equals(lastName)) {

                stud = currentStudent;
                break;
            }
        }
        return stud;
    }

    public String getStatistics() {
        String result = String.format("Classroom size: %d", this.students.size());
        for (Student student : this.students) {
            result += String.format("\n  ==Student: First Name= %s , Last Name= %s , Best Subject= %s", student.getFirstName(), student.getLastName(), student.getBestSubject());

        }
        return result;
    }
}
