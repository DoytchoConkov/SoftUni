package HealthyHeaven;

public class Vegetable {
    private String name;
    private int calories;

    public String getName() {
        return name;
    }

    public int getCalories() {
        return calories;
    }

    @Override
    public String toString() {
        return String.format(" - %s have %.2f calories", this.name, this.calories);
    }
}
