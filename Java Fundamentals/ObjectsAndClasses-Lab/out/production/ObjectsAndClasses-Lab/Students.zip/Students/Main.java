package Students;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        List<Students> students = new ArrayList<>();
        String input = scan.nextLine();
        while (!"end".equals(input)) {
            String[] token = input.split("\\s+");
            Students student = new Students();
            student.setFirstName(token[0]);
            student.setLastName(token[1]);
            student.setAge(Integer.parseInt(token[2]));
            student.setHometown(token[3]);
            students.add(student);
            input = scan.nextLine();
        }
        String town = scan.nextLine();
        for (Students students1 : students) {
            if (students1.getHometown().equals(town)) {
                System.out.printf("%s %s is %d years old%n", students1.getFirstName(), students1.getLastName(), students1.getAge());
            }
        }
    }
}
