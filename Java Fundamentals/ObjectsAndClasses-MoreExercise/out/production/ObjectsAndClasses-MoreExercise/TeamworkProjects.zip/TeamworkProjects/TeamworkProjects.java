package TeamworkProjects;

public class TeamworkProjects {
    private String name;
    private String projectName;


    public TeamworkProjects(String name, String projectName) {
        this.name = name;
        this.projectName = projectName;
    }

    public String getName() {
        return name;
    }

    public String getProjectName() {
        return projectName;
    }
}
