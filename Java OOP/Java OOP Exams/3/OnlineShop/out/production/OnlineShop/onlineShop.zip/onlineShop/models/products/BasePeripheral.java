package onlineShop.models.products;

import onlineShop.models.products.peripherals.Peripheral;

public abstract class BasePeripheral extends BaseComponent implements Peripheral {
    private String connectionType;

    protected BasePeripheral(int id, String manufacturer, String model, double price, double overallPerformance, int generation, String connectionType) {
        super(id, manufacturer, model, price, overallPerformance, generation);
        this.connectionType = connectionType;
    }

    @Override
    public String toString() {
        return super.toString() + " Connection Type: " + this.connectionType;
    }
}
