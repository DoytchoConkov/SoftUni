package onlineShop.models.products;

import onlineShop.models.products.components.Component;
import onlineShop.models.products.computers.Computer;
import onlineShop.models.products.peripherals.Peripheral;

import java.util.ArrayList;
import java.util.List;

public abstract class BaseComputer extends BaseProduct implements Computer {
    private List<BaseComponent> components;
    private List<BasePeripheral> peripherals;

    protected BaseComputer(int id, String manufacturer, String model, double price, double overallPerformance) {
        super(id, manufacturer, model, price, overallPerformance);
        this.components = new ArrayList<>();
        this.peripherals = new ArrayList<>();
    }

    @Override
    public double getOverallPerformance(){
        return 0.0;
    }

    @Override
    public double getPrice(){
        return 0.0;
    }

    protected void addPeripherial(Peripheral peripheral) {

    }

    @Override
    public String toString() {
        return "BaseComputer{}";
    }
}
