package robotService.core.interfaces;

public interface Engine extends Runnable {
}
