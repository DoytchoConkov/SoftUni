package CounterStriker.common;

public enum Command {
    AddGun,
    AddPlayer,
    Report,
    StartGame,
    Exit
}
