package exam.models.entities;

public enum ArtistName {
    Queen, Metallica, Madonna;
}
