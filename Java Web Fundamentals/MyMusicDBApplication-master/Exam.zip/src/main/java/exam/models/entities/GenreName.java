package exam.models.entities;

public enum GenreName {
    Pop, Rock, Metal, Other;
}
